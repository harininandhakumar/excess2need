import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import admin from 'firebase-admin';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Basic checks
const PORT = process.env.PORT || 8080;
const PROJECT_ID = process.env.FIREBASE_PROJECT_ID;
const GAC = process.env.GOOGLE_APPLICATION_CREDENTIALS;
if (!GAC || !PROJECT_ID) {
  console.warn('[WARN] Missing GOOGLE_APPLICATION_CREDENTIALS or FIREBASE_PROJECT_ID in .env');
}

// Firebase Admin init (relies on GOOGLE_APPLICATION_CREDENTIALS env var pointing to a JSON file)
if (!admin.apps.length) {
  admin.initializeApp({
    projectId: PROJECT_ID,
    credential: admin.credential.applicationDefault(),
  });
}
const db = admin.firestore();

const app = express();

// CORS
const allowed = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: function (origin, cb) {
    if (!origin) return cb(null, true); // Allow same-origin / curl
    if (allowed.includes(origin)) return cb(null, true);
    return cb(new Error('CORS not allowed for origin: ' + origin));
  },
  credentials: true,
}));

app.use(morgan('dev'));
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Auth middleware: verifies Firebase ID token from Authorization: Bearer <token>
async function requireAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing id token' });
    const decoded = await admin.auth().verifyIdToken(token);
    req.user = decoded;
    next();
  } catch (err) {
    console.error('Auth error:', err);
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// Health
app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ----- Food Items -----
// Create food item (auth)
app.post('/api/food', requireAuth, async (req, res) => {
  try {
    const { name, quantity, price, ingredients, description, city, image } = req.body;
    if (!name || !quantity || !city) {
      return res.status(400).json({ error: 'name, quantity and city are required' });
    }
    const donor = {
      uid: req.user.uid,
      name: req.user.name || req.user.displayName || 'Anonymous',
      email: req.user.email || '',
      city,
    };
    const doc = {
      name,
      quantity,
      price: typeof price === 'number' ? price : Number(price) || 0,
      ingredients: ingredients || '',
      description: description || '',
      donor,
      image: image || '',
      datePosted: admin.firestore.FieldValue.serverTimestamp(),
      available: true,
    };
    const ref = await db.collection('foodItems').add(doc);
    const snap = await ref.get();
    res.json({ id: ref.id, ...snap.data() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create food item' });
  }
});

// List available food (public)
app.get('/api/food', async (req, res) => {
  try {
    const q = await db.collection('foodItems').where('available', '==', true).orderBy('datePosted', 'desc').get();
    const items = q.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json(items);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list food' });
  }
});

// List my food (auth)
app.get('/api/food/mine', requireAuth, async (req, res) => {
  try {
    const q = await db.collection('foodItems').where('donor.uid', '==', req.user.uid).orderBy('datePosted', 'desc').get();
    const items = q.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json(items);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list my food' });
  }
});

// Toggle availability (auth)
app.patch('/api/food/:id/availability', requireAuth, async (req, res) => {
  try {
    const { available } = req.body;
    const ref = db.collection('foodItems').doc(req.params.id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ error: 'Not found' });
    if (snap.data().donor.uid !== req.user.uid) return res.status(403).json({ error: 'Not your item' });
    await ref.update({ available: !!available });
    const updated = await ref.get();
    res.json({ id: updated.id, ...updated.data() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update availability' });
  }
});

// ----- Orders -----
// Place order (auth) — Note: No payment integration (as requested)
app.post('/api/orders', requireAuth, async (req, res) => {
  try {
    const { foodItemId, quantity, instructions, pickupTime } = req.body;
    if (!foodItemId || !quantity || !pickupTime) {
      return res.status(400).json({ error: 'foodItemId, quantity, pickupTime required' });
    }
    const foodRef = db.collection('foodItems').doc(foodItemId);
    const foodSnap = await foodRef.get();
    if (!foodSnap.exists) return res.status(404).json({ error: 'Food item not found' });
    const food = foodSnap.data();
    if (!food.available) return res.status(400).json({ error: 'Item no longer available' });

    const order = {
      foodItemId,
      donorUid: food.donor.uid,
      buyer: {
        uid: req.user.uid,
        name: req.user.name || req.user.displayName || 'Buyer',
        email: req.user.email || '',
      },
      quantity: Number(quantity),
      totalPrice: (Number(food.price) || 0) * Number(quantity),
      instructions: instructions || '',
      pickupTime: new Date(pickupTime).toISOString(),
      status: 'pending',
      dateOrdered: admin.firestore.FieldValue.serverTimestamp(),
    };
    const ref = await db.collection('orders').add(order);
    res.json({ id: ref.id, ...order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to place order' });
  }
});

// Donor: see received orders (auth)
app.get('/api/orders/received', requireAuth, async (req, res) => {
  try {
    const q = await db.collection('orders').where('donorUid', '==', req.user.uid).orderBy('dateOrdered', 'desc').get();
    const items = q.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json(items);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// Buyer: see my orders (auth)
app.get('/api/orders/mine', requireAuth, async (req, res) => {
  try {
    const q = await db.collection('orders').where('buyer.uid', '==', req.user.uid).orderBy('dateOrdered', 'desc').get();
    const items = q.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json(items);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch my orders' });
  }
});

// Fallback to SPA index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`FoodConnect server running on http://localhost:${PORT}`);
});
