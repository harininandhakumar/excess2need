// Firebase init
firebase.initializeApp(window.__FIREBASE_CONFIG__);
const auth = firebase.auth();

// Simple helpers
const $ = (id) => document.getElementById(id);
function notify(msg, type='success') {
  const n = $('notification'); const t = $('notificationText');
  t.textContent = msg;
  n.className = `notification ${type==='success' ? 'bg-green-500' : 'bg-red-500'} text-white px-6 py-4 rounded-lg shadow-lg`;
  n.classList.remove('hidden'); setTimeout(()=> n.classList.add('hidden'), 4000);
}
function showSection(id) {
  const sections = ['homepage','donorRegister','browseFood','placeOrder','orderConfirmation','donorDashboard'];
  sections.forEach(s => { const el = $(s); if (el) el.classList.add('hidden'); });
  const el = $(id); if (el) { el.classList.remove('hidden'); el.classList.add('fade-in'); }
}

let currentUser = null;
let token = null;
let currentFoodItem = null;

// Auth UI
function openAuthModal(){ $('authModal').classList.remove('hidden'); $('authModal').classList.add('flex'); }
function closeAuthModal(){ $('authModal').classList.add('hidden'); $('authModal').classList.remove('flex'); }

$('loginBtn').addEventListener('click', openAuthModal);
$('closeAuth').addEventListener('click', closeAuthModal);
$('logoutBtn').addEventListener('click', async ()=> { await auth.signOut(); });

$('emailSignup').addEventListener('click', async ()=>{
  const email = $('authEmail').value.trim();
  const pass = $('authPassword').value;
  if (!email || pass.length < 6) return notify('Enter email and 6+ char password','error');
  try {
    await auth.createUserWithEmailAndPassword(email, pass);
    notify('Signed up successfully');
    closeAuthModal();
  } catch(e){ console.error(e); notify(e.message,'error'); }
});

$('emailLogin').addEventListener('click', async ()=>{
  const email = $('authEmail').value.trim();
  const pass = $('authPassword').value;
  if (!email || pass.length < 6) return notify('Enter email and password','error');
  try {
    await auth.signInWithEmailAndPassword(email, pass);
    notify('Welcome back!');
    closeAuthModal();
  } catch(e){ console.error(e); notify(e.message,'error'); }
});

auth.onAuthStateChanged(async (user)=>{
  currentUser = user;
  if (user) {
    token = await user.getIdToken();
    $('authUser').textContent = user.email;
    $('logoutBtn').classList.remove('hidden');
    $('loginBtn').classList.add('hidden');
    // default: show homepage
  } else {
    token = null;
    $('authUser').textContent = '';
    $('logoutBtn').classList.add('hidden');
    $('loginBtn').classList.remove('hidden');
  }
});

// Nav buttons
$('homeBtn').addEventListener('click', ()=> showSection('homepage'));
$('shareBtn').addEventListener('click', ()=> {
  if (!currentUser) return openAuthModal();
  showSection('donorRegister');
});
$('buyBtn').addEventListener('click', ()=> {
  showSection('browseFood'); loadFoodItems();
});
$('becomeSharer').addEventListener('click', ()=> {
  if (!currentUser) return openAuthModal();
  showSection('donorRegister');
});
$('addMoreFood').addEventListener('click', ()=> showSection('donorRegister'));

// API helper
async function api(path, opts={}){
  const headers = { 'Content-Type': 'application/json', ...(opts.headers||{}) };
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch((window.__API_BASE__||'') + path, { ...opts, headers });
  if (!res.ok) {
    const err = await res.json().catch(()=>({error: res.statusText}));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

// Food image placeholder
function getFoodImage(name){
  const img = {
    'Biryani': 'https://images.unsplash.com/photo-1563379091339-03246963d7d3?w=400&h=300&fit=crop',
    'Dal': 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop',
    'Butter Chicken': 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?w=400&h=300&fit=crop',
    'Roti': 'https://images.unsplash.com/photo-1574653339244-2b9700dc7b53?w=400&h=300&fit=crop',
    'Rice': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=300&fit=crop',
    'Samosa': 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=300&fit=crop',
    'Chole': 'https://images.unsplash.com/photo-1626132647523-66f9bf380027?w=400&h=300&fit=crop',
    'Rajma': 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
    'Palak Paneer': 'https://images.unsplash.com/photo-1631452180539-96aca7d48617?w=400&h=300&fit=crop',
    'Aloo Sabzi': 'https://images.unsplash.com/photo-1506280754576-f6fa8a873550?w=400&h=300&fit=crop'
  };
  return img[name] || 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400&h=300&fit=crop';
}

// Load food for browsing (public)
async function loadFoodItems(){
  try {
    const list = await api('/api/food', { method: 'GET' });
    const grid = $('foodGrid'); const noMsg = $('noFoodMessage');
    if (!list.length) { grid.innerHTML=''; noMsg.classList.remove('hidden'); return; }
    noMsg.classList.add('hidden');
    grid.innerHTML = list.map(item => `
      <div class="food-card bg-white rounded-lg shadow-lg overflow-hidden">
        <img src="${item.image || getFoodImage(item.name)}" alt="${item.name}" class="food-image">
        <div class="p-6">
          <h3 class="text-xl font-semibold mb-2">${item.name}</h3>
          <p class="text-gray-600 mb-2"><i class="fas fa-utensils mr-2"></i>${item.quantity}</p>
          <p class="text-green-600 font-semibold mb-2"><i class="fas fa-rupee-sign mr-1"></i>${item.price ?? 0}</p>
          <p class="text-sm text-gray-500 mb-4"><strong>Ingredients:</strong> ${item.ingredients}</p>
          <div class="flex items-center justify-between mb-4">
            <div class="text-sm text-gray-500"><i class="fas fa-map-marker-alt mr-1"></i>${item.donor?.city || ''}</div>
            <div class="text-sm text-gray-500"><i class="fas fa-clock mr-1"></i>${item.datePosted?.toDate ? item.datePosted.toDate().toLocaleDateString() : ''}</div>
          </div>
          <button data-id="${item.id}" class="order-now w-full btn-secondary text-white py-2 rounded-lg font-semibold">
            <i class="fas fa-shopping-cart mr-2"></i>Order Now
          </button>
        </div>
      </div>
    `).join('');
    Array.from(document.querySelectorAll('.order-now')).forEach(btn => {
      btn.addEventListener('click', () => selectFoodItem(btn.getAttribute('data-id'), list));
    });
  } catch(e){ console.error(e); notify(e.message,'error'); }
}

function selectFoodItem(id, list){
  const item = list.find(x=> x.id===id);
  if (!item) return;
  currentFoodItem = item;
  showOrderForm();
}

function showOrderForm(){
  showSection('placeOrder');
  const d = $('orderDetails');
  const it = currentFoodItem;
  d.innerHTML = `
    <div class="bg-gray-50 p-6 rounded-lg">
      <div class="flex items-start space-x-4">
        <img src="${it.image || getFoodImage(it.name)}" alt="${it.name}" class="w-24 h-24 object-cover rounded-lg">
        <div class="flex-1">
          <h3 class="text-xl font-semibold mb-2">${it.name}</h3>
          <p class="text-gray-600 mb-1"><i class="fas fa-utensils mr-2"></i>${it.quantity}</p>
          <p class="text-green-600 font-semibold mb-2"><i class="fas fa-rupee-sign mr-1"></i>${it.price ?? 0}</p>
          <p class="text-sm text-gray-500"><strong>By:</strong> ${it.donor?.name || 'Donor'}</p>
          <p class="text-sm text-gray-500"><i class="fas fa-map-marker-alt mr-1"></i>${it.donor?.city || ''}</p>
        </div>
      </div>
    </div>
  `;
}

$('orderForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  if (!currentUser) return openAuthModal();
  try {
    const body = {
      foodItemId: currentFoodItem.id,
      quantity: $('orderQuantity').value,
      instructions: $('orderInstructions').value,
      pickupTime: $('pickupTime').value
    };
    const res = await api('/api/orders', { method: 'POST', body: JSON.stringify(body) });
    showOrderConfirmation(res);
    notify('Order placed successfully!');
  } catch(e){ console.error(e); notify(e.message,'error'); }
});

function showOrderConfirmation(order){
  showSection('orderConfirmation');
  const c = $('confirmationDetails');
  c.innerHTML = `
    <h3 class="font-semibold mb-4">Order Details:</h3>
    <div class="space-y-2">
      <p><strong>Food Item:</strong> ${currentFoodItem.name}</p>
      <p><strong>Quantity:</strong> ${order.quantity} serving(s)</p>
      <p><strong>Total Price:</strong> ₹${order.totalPrice ?? 0}</p>
      <p><strong>Pickup Time:</strong> ${new Date(order.pickupTime).toLocaleString()}</p>
      ${order.instructions ? `<p><strong>Instructions:</strong> ${order.instructions}</p>` : ''}
    </div>
  `;
}

$('backToBrowse').addEventListener('click', ()=> { showSection('browseFood'); loadFoodItems(); });
$('backHome').addEventListener('click', ()=> showSection('homepage'));

// Donor: create food item
$('foodForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  if (!currentUser) return openAuthModal();
  try {
    const body = {
      name: $('foodName').value,
      city: $('foodCity').value,
      quantity: $('foodQuantity').value,
      price: Number($('foodPrice').value || 0),
      ingredients: $('foodIngredients').value,
      description: $('foodDescription').value,
      image: getFoodImage($('foodName').value)
    };
    const created = await api('/api/food', { method:'POST', body: JSON.stringify(body) });
    notify('Food item posted!');
    loadDonorDashboard();
  } catch(e){ console.error(e); notify(e.message,'error'); }
});

async function loadDonorDashboard(){
  try {
    const myFood = await api('/api/food/mine', { method:'GET' });
    const donorFoodItems = $('donorFoodItems');
    donorFoodItems.innerHTML = myFood.map(item => `
      <div class="border border-gray-200 rounded-lg p-4 mb-4">
        <div class="flex items-start space-x-4">
          <img src="${item.image || getFoodImage(item.name)}" alt="${item.name}" class="w-16 h-16 object-cover rounded-lg">
          <div class="flex-1">
            <h4 class="font-semibold">${item.name}</h4>
            <p class="text-sm text-gray-600">${item.quantity} - ₹${item.price ?? 0}</p>
            <span class="inline-block px-2 py-1 text-xs rounded-full ${item.available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
              ${item.available ? 'Available' : 'Sold Out'}
            </span>
          </div>
        </div>
      </div>
    `).join('');
    const rec = await api('/api/orders/received', { method:'GET' });
    const receivedOrders = $('receivedOrders');
    receivedOrders.innerHTML = rec.map(order => `
      <div class="border border-gray-200 rounded-lg p-4 mb-4">
        <div class="flex justify-between items-start mb-2">
          <h4 class="font-semibold">${order.foodItemId}</h4>
          <span class="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">${order.status}</span>
        </div>
        <p class="text-sm text-gray-600">Quantity: ${order.quantity} serving(s)</p>
        <p class="text-sm text-gray-600">Buyer: ${order.buyer?.name || order.buyer?.email || ''}</p>
        <p class="text-sm text-gray-600">Pickup: ${new Date(order.pickupTime).toLocaleString()}</p>
        ${order.instructions ? `<p class="text-sm text-gray-600">Note: ${order.instructions}</p>` : ''}
      </div>
    `).join('');
    showSection('donorDashboard');
  } catch(e){ console.error(e); notify(e.message,'error'); }
}

// Default landing
showSection('homepage');
