# FoodConnect (Firebase Auth + Node/Express + Firestore)

Community app to share surplus homemade food and help those in need.  
- Frontend: HTML + Tailwind + Vanilla JS + Firebase Auth (email/password)  
- Backend: Node.js (Express) + Firebase Admin SDK (Firestore)  
- No payments are collected; orders are placed and coordinated for pickup.

## 1) Firebase Setup
1. Create a Firebase project.
2. Enable **Email/Password** in Authentication.
3. Create a **Web App** and copy its config (apiKey, authDomain, projectId, appId).
4. Download a **Service Account** key (JSON) for Admin SDK.

## 2) Backend Setup
```bash
cd foodconnect-firebase-node
cp .env.example .env
# Edit .env to set FIREBASE_PROJECT_ID and GOOGLE_APPLICATION_CREDENTIALS
# Put your serviceAccountKey.json on disk and set the absolute path in .env
npm install
npm run start   # or: npm run dev
```
Server will run on http://localhost:8080

## 3) Frontend Setup
- Open `public/index.html`, set `window.__FIREBASE_CONFIG__` to your Web App config.
- If your server is on a different host/port, set `window.__API_BASE__` accordingly (e.g. `http://localhost:8080`).

Now open http://localhost:8080 in your browser.

## API (quick)
- `GET /api/food` — list available food (public)
- `POST /api/food` — create food (auth)
- `GET /api/food/mine` — list my food (auth)
- `PATCH /api/food/:id/availability` — toggle (auth/owner)
- `POST /api/orders` — place order (auth)
- `GET /api/orders/received` — donor orders (auth)
- `GET /api/orders/mine` — buyer orders (auth)

## Notes
- This demo uses Firestore via Admin SDK on the server. Make sure the service account matches your project.
- CORS origins are controlled via `.env` (`CORS_ORIGINS`). Update if you host frontend separately.
- No payment integration; a **Thank You** block appears after order confirmation.
